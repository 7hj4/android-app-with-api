package com.example.login_and_register_with_api;

public class services {

    public static String url_login = "http://192.168.43.154/api_login/login/index.php";

    public static String url_register = "http://192.168.43.154/api_login/signup/index.php";

    //public static String url_profile = "http://192.168.43.154/api_mobile/User/profile/";



}
