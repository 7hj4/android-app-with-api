package com.example.login_and_register_with_api;

public class User {
    private int id;
    private String username, email;

    public User(int id, String username, String email) {
        this.id = id;
        this.username = username;
        this.email = email;

    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

}
